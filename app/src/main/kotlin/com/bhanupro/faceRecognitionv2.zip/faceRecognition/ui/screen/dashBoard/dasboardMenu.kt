package com.krishnaZyala.faceRecognition.ui.screen.dashBoard

import UserCard
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.krishnaZyala.faceRecognition.data.model.AppState
import com.krishnaZyala.faceRecognition.ui.navigation.LocalGlobalViewModel
import kotlinx.coroutines.launch
import androidx.compose.material3.Icon
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Password
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DoorControlDashboard(state: AppState) {
    val scope = rememberCoroutineScope()
    val showChangeLogin = remember { mutableStateOf(false) }
    val showPincodeDialog = remember { mutableStateOf(false) }
    val pincode = remember { mutableStateOf("") }
    val globalViewModel = LocalGlobalViewModel.current
    val user by globalViewModel.userData.collectAsState()
LaunchedEffect(Unit) {
    globalViewModel.resetTimeout()
}
    val items = listOf(
        DashboardItem("Unlock by Face", Icons.Default.Face) {
            state.host.navigate("home")
        },
        DashboardItem("PIN",   Icons.Filled.Password) {
            // TODO: Handle call action
            showPincodeDialog.value = true // fallback
        },
        DashboardItem("Call", Icons.Default.Call) {
            // TODO: Handle call action
        },

        DashboardItem("More Options", Icons.Default.Settings) {
            // TODO: Open settings or extra actions
        },
        DashboardItem("Change User", Icons.Default.Person) {
            showChangeLogin.value = true
        }
    )
    var showSettings by remember { mutableStateOf(false) }
    if (showSettings) {
        DeviceControlsModal(onDismiss = { showSettings = false })
    }
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopAppBar(
                title = { Text("Door Control", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = {
                    showSettings=true
                    }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )

            UserCard( user,
                modifier = Modifier.padding(12.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 160.dp),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(items) { item ->
                    ActionCard(item = item)
                }
            }
        }
    }

    if (showPincodeDialog.value) {
        PincodeDialog(
            pincode = pincode.value,
            onValueChange = { pincode.value = it },
            onConfirm = {
                showPincodeDialog.value = false
                scope.launch {
                    // Handle PIN confirmation
                }
            },
            onDismiss = { showPincodeDialog.value = false }
        )
    }

    if (showChangeLogin.value) {
        ChangeUserDialog(
            onConfirm = { showChangeLogin.value = false },
            onDismiss = { showChangeLogin.value = false }
        )
    }
}

@Composable
private fun ActionCard(item: DashboardItem) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .scale(scale)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { item.onClick() }
                )
            }
            .shadow(
                elevation = 12.dp,
                shape = RoundedCornerShape(20.dp),
                clip = false
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surfaceVariant,
                            MaterialTheme.colorScheme.surface
                        )
                    )
                )
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .background(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center,

            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = item.title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = item.title,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(horizontal = 8.dp),
                maxLines = 2
            )
        }
    }
}

@Composable
private fun PincodeDialog(
    pincode: String,
    onValueChange: (String) -> Unit,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Lock Icon",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Enter Security PIN",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                OutlinedTextField(
                    value = pincode,
                    onValueChange = onValueChange,
                    label = { Text("PIN Code") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth(0.85f)
                )
                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Face,
                        contentDescription = "Face Unlock",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        "Use Face Unlock",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(pincode) },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.padding(horizontal = 8.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = "Unlock")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Unlock")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.padding(horizontal = 8.dp)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Cancel")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Cancel")
            }
        },
        shape = RoundedCornerShape(24.dp),
        containerColor = MaterialTheme.colorScheme.surface
    )
}


@Composable
private fun ChangeUserDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Change User / Login") },
        text = {
            Text("Open the user management screen to switch accounts or register a new face/pincode.")
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Open") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

private data class DashboardItem(
    val title: String,
    val icon: ImageVector,
    val onClick: () -> Unit
)
