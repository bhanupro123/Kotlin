package com.krishnaZyala.faceRecognition.ui.navigation

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.PowerManager
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.krishnaZyala.faceRecognition.data.model.AppState
import com.krishnaZyala.faceRecognition.ui.screen.dashBoard.DoorControlDashboard
import com.krishnaZyala.faceRecognition.ui.screen.multiServer.MultiServerScreen
import com.krishnaZyala.faceRecognition.ui.screen.home.AudioStream
import com.krishnaZyala.faceRecognition.ui.screen.home.HomeScreen
import com.krishnaZyala.faceRecognition.ui.screen.home.InitScreen
import com.krishnaZyala.faceRecognition.ui.screen.home.PermissionsScreen
import com.krishnaZyala.faceRecognition.ui.screen.home.VideoReceiverScreen
import com.krishnaZyala.faceRecognition.ui.screen.ownServer.OwnServerScreen
import kotlinx.coroutines.CoroutineScope

// --- Add these imports for your global ViewModel and CompositionLocal ---
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.input.pointer.pointerInput
import com.krishnaZyala.faceRecognition.MyDeviceAdminReceiver
import com.krishnaZyala.faceRecognition.app.SnackbarManager
import com.krishnaZyala.faceRecognition.ui.global.GlobalViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch


// --- CompositionLocal for GlobalViewModel ---
val LocalGlobalViewModel = staticCompositionLocalOf<GlobalViewModel> {
    error("GlobalViewModel not provided")
}

@Composable
fun AppHost(
    startDestination: String,
    modifier: Modifier = Modifier,
    route: String? = null,
    scope: CoroutineScope = rememberCoroutineScope(),
    host: NavHostController = rememberNavController(),
    activity: Activity = LocalContext.current as Activity,
    snackbar: SnackbarHostState = remember { SnackbarHostState() },
    state: AppState = AppState(activity, scope, host, snackbar),
    builder: NavGraphBuilder.() -> Unit = appNavGraphBuilder(state),
) {
    val context = LocalContext.current
    // Create and remember globalViewModel once per app lifecycle here
    val globalViewModel = remember { GlobalViewModel(context) }



    CompositionLocalProvider(LocalGlobalViewModel provides globalViewModel) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            globalViewModel.resetTimeout()
                        },
                        onPress = {
                            globalViewModel.resetTimeout()
                            tryAwaitRelease()
                        }
                    )
                }
        ) {
            NavHost(host, startDestination, modifier, route, builder)
        }
    }
    }


fun appNavGraphBuilder(state: AppState): NavGraphBuilder.() -> Unit = {
    composable("splash") {
        InitScreen(appState = state)
    }
    composable("home") {
        HomeScreen(state)
    }
    composable("dashboard") {
        DoorControlDashboard(state)
    }
    composable("audioStream") {
        AudioStream(state)
    }
    composable("permissions") {
        PermissionsScreen(state)
    }
    composable("media") {
        VideoReceiverScreen()
    }
    composable("ownserver") {
        OwnServerScreen()
    }
    composable("multiserver") {
        MultiServerScreen()
    }
}
