package com.krishnaZyala.faceRecognition.ui.screen.Init

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.krishnaZyala.faceRecognition.ui.screen.ownServer.MultipleStreamViewModel

@Composable
fun OwnServerScreen(viewModel: MultipleStreamViewModel = viewModel()) {
    val context = LocalContext.current
    val streams by viewModel.streams.collectAsState()
    val focusedId by viewModel.focusedStreamId.collectAsState()
    val selfBitmap by viewModel.selfBitmap.collectAsState()

    // Start everything once when composable is first launched
    LaunchedEffect(Unit) {
        viewModel.startCamera(context)
        viewModel.startSendingAudio(context)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        StreamGrid(streams = streams, onClick = { viewModel.focusStream(it.senderId) })

        // Overlay own camera preview in top-left corner
        selfBitmap?.let { bitmap ->
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Self preview",
                modifier = Modifier
                    .padding(8.dp)
                    .size(120.dp)
                    .align(Alignment.TopStart)
                    .background(Color.Black.copy(alpha = 0.4f))
            )
        }

        // Fullscreen preview
        if (focusedId != null) {
            FocusedStreamDialog(
                stream = streams.find { it.senderId == focusedId },
                onDismiss = { viewModel.clearFocus() }
            )
        }
    }
}

@Composable
fun StreamGrid(
    streams: List<RemoteStream>,
    onClick: (RemoteStream) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        contentPadding = PaddingValues(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(streams, key = { it.senderId }) { stream ->
            StreamItem(stream, onClick)
        }
    }
}

@Composable
fun StreamItem(
    stream: RemoteStream,
    onClick: (RemoteStream) -> Unit
) {
    Card(
        modifier = Modifier
            .padding(6.dp)
            .fillMaxWidth()
            .aspectRatio(3f / 4f)
            .clickable { onClick(stream) },
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Image(
            bitmap = stream.bitmap.asImageBitmap(),
            contentDescription = "Stream from ${stream.senderId}",
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun FocusedStreamDialog(
    stream: RemoteStream?,
    onDismiss: () -> Unit
) {
    if (stream == null) return

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = MaterialTheme.shapes.medium,
            tonalElevation = 8.dp
        ) {
            Box(modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(3f / 4f)
                .clickable { onDismiss() }
            ) {
                Image(
                    bitmap = stream.bitmap.asImageBitmap(),
                    contentDescription = "Focused Stream",
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

