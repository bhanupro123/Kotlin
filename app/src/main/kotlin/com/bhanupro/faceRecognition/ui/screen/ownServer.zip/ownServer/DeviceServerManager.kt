package com.krishnaZyala.faceRecognition.ui.screen.ownServer

import android.content.Context
import android.graphics.BitmapFactory
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import com.krishnaZyala.faceRecognition.ui.screen.Init.RemoteStream
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import okhttp3.*
import okio.ByteString
import org.json.JSONObject
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
fun getWifiIpAddress(context: Context): String? {
    val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    val ip = wm.connectionInfo.ipAddress
    return if (ip != 0) {
        // Convert little-endian to big-endian if needed
        val ipAddress = String.format(
            "%d.%d.%d.%d",
            ip and 0xff,
            ip shr 8 and 0xff,
            ip shr 16 and 0xff,
            ip shr 24 and 0xff
        )
        ipAddress
    } else {
        null
    }
}

data class DeviceInfo(
    val id: String,
    val name: String,
    val ip: String
)

class DeviceServerManager(
    private val context: Context,
    private val onNewVideo: (String, ByteBuffer?) -> Unit,
    private val onNewAudio: (ByteBuffer?) -> Unit
) {
    private val connectedDevices = ConcurrentHashMap<WebSocket, String>()
    private var audioTrack: AudioTrack? = null
    private val ip=getWifiIpAddress(context)
    private val deviceId = "Bhanu"
    private val deviceName = "${Build.MANUFACTURER} ${Build.MODEL}"
    private val fullId = "$deviceId-$deviceName"

    private val masterHttpClient = OkHttpClient()
    private val httpMultiClients = OkHttpClient()

    private val videoServer = object : WebSocketServer(InetSocketAddress(8081)) {
        override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
            Log.d("Signaling", "Client connected: ${conn.remoteSocketAddress}")
        }

        override fun onMessage(conn: WebSocket, message: ByteBuffer?) {
            Log.d("Signaling", "Client connected: ${conn.remoteSocketAddress} message from")
            val id = connectedDevices[conn] ?: return
            onNewVideo(id, message)
        }

        override fun onMessage(conn: WebSocket, message: String) {
            connectedDevices[conn] = message  // Initial ID or name
        }

        override fun onClose(conn: WebSocket, code: Int, reason: String, remote: Boolean) {
            connectedDevices.remove(conn)
        }

        override fun onError(conn: WebSocket?, ex: Exception) {
            Log.e("VideoServer", "Error: ${ex.message}")
        }

        override fun onStart() {
            Log.i("Signaling", "Started on port 8081")
        }
    }

    private val audioServer = object : WebSocketServer(InetSocketAddress(8082)) {
        override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
            Log.d("AudioServer", "Client connected: ${conn.remoteSocketAddress}")
        }

        override fun onMessage(conn: WebSocket?, message: ByteBuffer?) {
            onNewAudio(message)
        }

        override fun onMessage(conn: WebSocket, message: String) {
            connectedDevices[conn] = message
        }

        override fun onClose(conn: WebSocket, code: Int, reason: String, remote: Boolean) {
            connectedDevices.remove(conn)
        }

        override fun onError(conn: WebSocket?, ex: Exception) {
            Log.e("AudioServer", "Error: ${ex.message}")
        }

        override fun onStart() {
            Log.i("AudioServer", "Started on port 8082")
        }
    }

    fun startServers() {
        videoServer.start()
        audioServer.start()
    }

    fun stopServers() {
        videoServer.stop()
        audioServer.stop()
        audioTrack?.release()
    }

    fun connectToSignalingServer(serverUrl: String = "ws://192.168.0.149:8080") {
        val request = Request.Builder().url(serverUrl).build()

        masterHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: okhttp3.WebSocket, response: Response) {
                Log.e("Signaling", "Opend")
                val json = """
                    {
                        "id": "$deviceId",
                        "name": "$fullId",
                        "ip":"$ip",
                          "type":"Video/Audio"
                    }
                """.trimIndent()
                ws.send(json)
            }

            override fun onMessage(webSocket: okhttp3.WebSocket, bytes: ByteString) {
                Log.e("Signaling", "BYTES")
            }
            override fun onMessage(ws: okhttp3.WebSocket, text: String) {
                Log.e("Signaling", text)

                try {
                    val obj = JSONObject(text)
                    if (obj.getString("type") == "call") {

                    }
                    else  if (obj.getString("type") == "new_device") {
                        val deviceJson = obj.getJSONObject("device")
                        val device = DeviceInfo(
                            id = deviceJson.getString("id"),
                            name = deviceJson.getString("name"),
                            ip = deviceJson.getString("ip")
                        )

                        connectToPeer(device)
                    }
                } catch (e: Exception) {
                     Log.e("Signaling", "Failed to parse device info: ${e.message}")
                }
            }

            override fun onFailure(ws: okhttp3.WebSocket, t: Throwable, response: Response?) {
                Log.e("Signaling", "Connection failed: ${t.message}")
            }
        })
    }

    private fun connectToPeer(device: DeviceInfo) {
        Log.e("Signaling", "Trying to connect to peer: ${device.name} (${device.ip})")

        fun connectVideo() {
            val videoUrl = "ws://${device.ip}:8081"
            val videoRequest = Request.Builder().url(videoUrl).build()

            httpMultiClients.newWebSocket(videoRequest, object : WebSocketListener() {
                override fun onOpen(ws: okhttp3.WebSocket, response: Response) {
                    Log.e("Signaling", "✅ Video connected to ${device.name}")
                    ws.send(fullId)
                }

                override fun onMessage(ws: okhttp3.WebSocket, bytes: ByteString) {
                    onNewVideo(device.id, bytes.asByteBuffer())
                }

                override fun onFailure(ws: okhttp3.WebSocket, t: Throwable, response: Response?) {
                    Log.e("Signaling", "❌ Video connection failed: ${t.message}")
                    Handler(Looper.getMainLooper()).postDelayed({
                        Log.e("Signaling", "🔄 Retrying video for ${device.name}")
                        connectVideo()
                    }, 5000)
                }

                override fun onClosed(ws: okhttp3.WebSocket, code: Int, reason: String) {
                    Log.e("Signaling", "⚠️ Video closed: $reason")
                    Handler(Looper.getMainLooper()).postDelayed({
                        connectVideo()
                    }, 5000)
                }
            })
        }

        fun connectAudio() {
            val audioUrl = "ws://${device.ip}:8082"
            val audioRequest = Request.Builder().url(audioUrl).build()

            httpMultiClients.newWebSocket(audioRequest, object : WebSocketListener() {
                override fun onOpen(ws: okhttp3.WebSocket, response: Response) {
                    Log.e("Signaling", "✅ Audio connected to ${device.name}")
                    ws.send(fullId)
                }

                override fun onMessage(ws: okhttp3.WebSocket, bytes: ByteString) {
                    onNewAudio(bytes.asByteBuffer())
                }

                override fun onFailure(ws: okhttp3.WebSocket, t: Throwable, response: Response?) {
                    Log.e("Signaling", "❌ Audio connection failed: ${t.message}")
                    Handler(Looper.getMainLooper()).postDelayed({
                        Log.e("Signaling", "🔄 Retrying audio for ${device.name}")
                        connectAudio()
                    }, 5000)
                }

                override fun onClosed(ws: okhttp3.WebSocket, code: Int, reason: String) {
                    Log.e("Signaling", "⚠️ Audio closed: $reason")
                    Handler(Looper.getMainLooper()).postDelayed({
                        connectAudio()
                    }, 5000)
                }
            })
        }

        connectVideo()
        connectAudio()
    }


    fun broadcastVideo(data: ByteArray) {
        videoServer.connections.forEach { conn ->
            try {
                conn.send(data)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun broadcastAudio(data: ByteArray) {
        audioServer.connections.forEach { conn ->
            try {
                conn.send(data)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playAudio(data: ByteArray) {
        val sampleRate = 16000
        if (audioTrack == null) {
            val bufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            audioTrack = AudioTrack(
                AudioManager.STREAM_MUSIC,
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize,
                AudioTrack.MODE_STREAM
            )
            audioTrack?.play()
        }
        audioTrack?.write(data, 0, data.size)
    }
}
