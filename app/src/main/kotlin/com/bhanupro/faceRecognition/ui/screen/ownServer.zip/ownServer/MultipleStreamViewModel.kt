package com.krishnaZyala.faceRecognition.ui.screen.ownServer

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.*
import android.os.Build
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import com.krishnaZyala.faceRecognition.ui.screen.Init.RemoteStream
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.concurrent.thread

class MultipleStreamViewModel(application: Application) : AndroidViewModel(application) {

    private val _streams = MutableStateFlow<List<RemoteStream>>(emptyList())
    val streams: StateFlow<List<RemoteStream>> = _streams

    private val _selfBitmap = MutableStateFlow<Bitmap?>(null)
    val selfBitmap: StateFlow<Bitmap?> = _selfBitmap

    private val _focusedStreamId = MutableStateFlow<String?>(null)
    val focusedStreamId: StateFlow<String?> = _focusedStreamId

    private val context = application.applicationContext

    private val deviceServer = DeviceServerManager(
        context = context,
        onNewVideo = { senderId, buffer ->
            buffer?.let {
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                _streams.update { list ->
                    val mutable = list.toMutableList()
                    val index = mutable.indexOfFirst { it.senderId == senderId }
                    if (index >= 0) {
                        mutable[index] = RemoteStream(senderId, bitmap)
                    } else {
                        mutable.add(RemoteStream(senderId, bitmap))
                    }
                    mutable
                }
            }
        },
        onNewAudio = { buffer ->
            buffer?.let {
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                //deviceServer.playAudio(bytes)
            }
        }
    )

    fun focusStream(senderId: String) {
        _focusedStreamId.value = senderId
    }

    fun clearFocus() {
        _focusedStreamId.value = null
    }

    init {
        deviceServer.startServers()
        deviceServer.connectToSignalingServer()
    }

    fun startCamera(context: Context) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val provider = cameraProviderFuture.get()
            val preview = Preview.Builder().build()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            val executor = Executors.newSingleThreadExecutor()
            analysis.setAnalyzer(executor) { image ->
                val jpeg = yuvToJpeg(image)
                jpeg?.let {
                    val bmp = BitmapFactory.decodeByteArray(it, 0, it.size)
                    _selfBitmap.value = bmp
                    deviceServer.broadcastVideo(it)
                }
                image.close()
            }

            val selector = CameraSelector.DEFAULT_FRONT_CAMERA
            provider.unbindAll()
            provider.bindToLifecycle(context as androidx.lifecycle.LifecycleOwner, selector, preview, analysis)
        }, ContextCompat.getMainExecutor(context))
    }

    fun startSendingAudio(context: Context) {
        val sampleRate = 16000
        val bufferSize = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

      if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {    return
        }
        val recorder =    AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        recorder.startRecording()

        thread(start = true, isDaemon = true) {
            val buffer = ByteArray(bufferSize)
            while (true) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    deviceServer.broadcastAudio(buffer.copyOf(read))
                }
            }
        }
    }

    private fun yuvToJpeg(image: ImageProxy): ByteArray? {
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)

        val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
        val stream = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), 60, stream)
        return stream.toByteArray()
    }

    override fun onCleared() {
        deviceServer.stopServers()
        super.onCleared()
    }
}
