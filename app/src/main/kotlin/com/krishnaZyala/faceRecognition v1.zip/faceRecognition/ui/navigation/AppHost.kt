package com.krishnaZyala.faceRecognition.ui.navigation

import android.app.Activity
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.krishnaZyala.faceRecognition.data.model.AppState
import com.krishnaZyala.faceRecognition.ui.screen.multiServer.MultiServerScreen
import com.krishnaZyala.faceRecognition.ui.screen.home.AudioStream
import com.krishnaZyala.faceRecognition.ui.screen.home.HomeScreen
import com.krishnaZyala.faceRecognition.ui.screen.home.InitScreen
import com.krishnaZyala.faceRecognition.ui.screen.home.PermissionsScreen
import com.krishnaZyala.faceRecognition.ui.screen.home.VideoReceiverScreen
import com.krishnaZyala.faceRecognition.ui.screen.ownServer.OwnServerScreen
import kotlinx.coroutines.CoroutineScope

@Composable
fun AppHost(
    startDestination: String,
    modifier: Modifier = Modifier,
    route: String? = null,
    scope: CoroutineScope = rememberCoroutineScope(),
    host: NavHostController = rememberNavController(),
    activity: Activity = LocalContext.current as Activity,
    snackbar: SnackbarHostState = remember { SnackbarHostState() },
    state: AppState = AppState(activity, scope, host, snackbar),
    builder: NavGraphBuilder.() -> Unit = appNavGraphBuilder(state),
) = NavHost(host, startDestination, modifier, route, builder)



fun appNavGraphBuilder(state: AppState): NavGraphBuilder.() -> Unit = {
    composable("splash") {
        InitScreen(appState = state)
    }
    composable("home") {
        HomeScreen(state)
    }
    composable("audioStream") {
        AudioStream(state)
    }
    composable("permissions") {
        PermissionsScreen(state)
    }
    composable("media") {
        VideoReceiverScreen()
    }
    composable("ownserver") {
        OwnServerScreen()
    }

    composable("multiserver") {
        MultiServerScreen()
    }
}


